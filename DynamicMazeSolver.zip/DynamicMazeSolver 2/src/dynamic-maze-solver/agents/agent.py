# base class for agents

class Agent:
    def act(self, reward):
        pass

    def remember(self, replay):
        pass
